﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Web;
//using InventoryManagement.Models;
//using InventoryManagement.DTO;

//namespace InventoryManagement.Services
//{
//    public class SearchProductByCategory
//    {
//        private readonly inventoryDbContext _inventoryDbContext;
//        public SearchProductByCategory(inventoryDbContext inventoryDbContext)
//        {
//            _inventoryDbContext = inventoryDbContext;
//        }
//        public List<product> SearchProductByCategoryName(SearchProduct dto)
//        {
//            var productCategory = _inventoryDbContext.Category.Include("Products").FirstOrDefault(c=>c.CategoryName == dto.CategoryName);
//            if (productCategory == null)
//            {
//                return new List<product>();
//            }
//            return productCategory.Products.ToList();
            
//        }
//    }
//}