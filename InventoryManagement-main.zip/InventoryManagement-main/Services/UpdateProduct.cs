﻿using InventoryManagement.DTO;
using InventoryManagement.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Web;

namespace InventoryManagement.Services
{
    public class UpdateProduct
    {
        private readonly inventoryDbContext _inventoryDbContext;
        public UpdateProduct(inventoryDbContext inventoryDbContext)
        {
                _inventoryDbContext = inventoryDbContext;
        }
        public bool UpdatingProduct(UpdateProductList dto)
        {
            var UpdatedProduct = _inventoryDbContext.Products.Find(dto.productId);
            if (UpdatedProduct == null)
            {
                return false;
            }
            if (dto.quantity > 0)
            {
                UpdatedProduct.quantityInStock = UpdatedProduct.quantityInStock + dto.quantity; // increasing the stock 
            }
            if (dto.price > 0)
            {
                UpdatedProduct.price = dto.price; // setting the price
            }
            
            _inventoryDbContext.Entry(UpdatedProduct).State = EntityState.Modified; // updating the product list 
            _inventoryDbContext.SaveChanges();

            return true;
        }
    }
}