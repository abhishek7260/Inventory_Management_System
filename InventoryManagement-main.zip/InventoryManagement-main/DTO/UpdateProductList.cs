﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InventoryManagement.DTO
{
    public class UpdateProductList
    {
        public int productId { get; set; }
        public int quantity { get; set; }
        public decimal price {  get; set; }
    }
}