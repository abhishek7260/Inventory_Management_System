﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InventoryManagement.DTO
{
    public class CustomerLogin
    {
        
        public string Name { get; set; }
        public string email { get; set; }
    }
}