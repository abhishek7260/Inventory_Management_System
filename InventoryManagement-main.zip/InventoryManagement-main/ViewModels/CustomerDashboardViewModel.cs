﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Models;
using InventoryManagement.Services;
using InventoryManagement.DTO;

namespace InventoryManagement.ViewModels
{
    public class CustomerDashboardViewModel
    {
        public customer Customer { get; set; }
        public List<CartItem> CartItems { get; set; }
        public List<order> Orders { get; set; }
        public List<OrderProduct> OrderProducts { get; set; }
    }
}