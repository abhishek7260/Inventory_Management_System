﻿using InventoryManagement.Models;
using InventoryManagement.ViewModels;
using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace InventoryManagement.Controllers
{
    public class AccountController : Controller
    {
        inventoryDbContext db = new inventoryDbContext();

        [AllowAnonymous]
        [HttpGet]
        public ActionResult ForgotPassword()
        {
            return View();
        }
        [AllowAnonymous]

        [HttpPost]
        public ActionResult ForgotPassword(ForgotPasswordViewModel model)
        {
            System.Diagnostics.Debug.WriteLine(">>> ForgotPassword POST called");

            if (!ModelState.IsValid)
            {
                System.Diagnostics.Debug.WriteLine(">>> Model is invalid");
                return View(model);
            }
            var user = db.Customers.FirstOrDefault(u => u.Email == model.Email);
            if (user == null)
            {
                //ModelState.AddModelError("", "Email not found.");
                //return View();
                return Content("Email not found.");
            }

            string code = new Random().Next(100000, 999999).ToString();

            db.PasswordResetRequests.Add(new PasswordResetRequest
            {
                Email = model.Email,
                VerificationCode = code,
                RequestedAt = DateTime.Now,
                ExpiresAt = DateTime.Now.AddMinutes(1)
            });
            db.SaveChanges();

            TempData["Email"] = model.Email;
            TempData["Code"] = code;
            System.Diagnostics.Debug.WriteLine($">>> Redirecting to VerifyCode for {model.Email}");
            return RedirectToAction("VerifyCode","Account",new {email=model.Email});
            //return Content("Redirect worked. Now going to VerifyCode.");
        }

        [AllowAnonymous]
        [HttpGet]
        public ActionResult VerifyCode(string email)
        {
            var model=new VerifyCodeViewModel {Email = email};
            return View(model);
        }

        [AllowAnonymous]
        [HttpPost]
        public ActionResult VerifyCode(VerifyCodeViewModel model)
        {
           
            var expire = db.PasswordResetRequests.Where(u => u.ExpiresAt < DateTime.Now).ToList();
            if(expire.Count > 0)
            {
                db.PasswordResetRequests.RemoveRange(expire);
                db.SaveChanges();
                System.Diagnostics.Debug.WriteLine("Expired token deleted");
            }
            var request = db.PasswordResetRequests
               .FirstOrDefault(r => r.Email == model.Email && r.VerificationCode == model.VerificationCode);
            if (request == null)
            {
                ModelState.AddModelError("", "Invalid verification code.");
                return View(model);
            }
            if(request.ExpiresAt<DateTime.Now)
            {
                ModelState.AddModelError("", "Verification code has expired");
               
             
                //db.PasswordResetRequests.Remove(request);
                //db.SaveChanges();
                return Content("token has expired");
            }

            TempData["Email"] = model.Email;
            return RedirectToAction("ResetPassword");
        }
        [AllowAnonymous]
        [HttpGet]
        public ActionResult ResetPassword()
        {
            return View(new ResetPasswordViewModel
            {
                Email = TempData["Email"]?.ToString()
            });
        }
        [AllowAnonymous]
        [HttpPost]
        public ActionResult ResetPassword(ResetPasswordViewModel model)
        {
            if (!ModelState.IsValid)
            {
                var resetRequest = db.PasswordResetRequests.FirstOrDefault(r => r.Email == model.Email);
                if (resetRequest != null && resetRequest.ExpiresAt<DateTime.Now)
                {
                    db.PasswordResetRequests.Remove(resetRequest);
                    db.SaveChanges();
                    System.Diagnostics.Debug.WriteLine("✅ Reset request deleted");
                }
                return View(model);
            }

            var user = db.CustomerSign.FirstOrDefault(u => u.Email == model.Email);
            if (user == null)
            {
                ModelState.AddModelError("", "User not found.");

                return View(model);
            }
            user.Password = model.NewPassword;
            try
            {
                //user.Password = model.NewPassword;
                db.Configuration.ValidateOnSaveEnabled = false;
                db.Entry(user).Property(u => u.Password).IsModified = true;
                var resetRequest = db.PasswordResetRequests.FirstOrDefault(r => r.Email == model.Email);
                if (resetRequest != null)
                {
                    db.PasswordResetRequests.Remove(resetRequest);
                    db.SaveChanges();
                    System.Diagnostics.Debug.WriteLine("✅ Reset request deleted");
                }
              
                db.Configuration.ValidateOnSaveEnabled = true;

                TempData["Message"] = "Password has been reset successfully.";
                return RedirectToAction("ResetSuccess", "Account"); // <== THIS IS IMPORTANT
            }
            catch (DbEntityValidationException ex)
            {
                foreach (var failure in ex.EntityValidationErrors)
                {
                    foreach (var error in failure.ValidationErrors)
                    {
                        System.Diagnostics.Debug.WriteLine($"Property: {error.PropertyName}, Error: {error.ErrorMessage}");
                    }
                }

                ModelState.AddModelError("", "An error occurred while resetting your password.");
                return View(model);
            }
            //finally
            //{
            //    var request=db.PasswordResetRequests.ToList();
            //    foreach (var x in request)
            //    {
            //        if (x != null && x.ExpiresAt < DateTime.Now)
            //        {
            //            db.PasswordResetRequests.Remove(x);
            //            db.SaveChanges();
            //        }
            //    }
            //}
        }


        [AllowAnonymous]
        public ActionResult ResetSuccess()
        {
            return Content("Your password has been successfully reset.");
        }
        [HttpGet]
        public ActionResult Logout()
        {
            System.Web.Security.FormsAuthentication.SignOut();
            Session.Clear();
            return RedirectToAction("Login", "Login");
        }
    }
}