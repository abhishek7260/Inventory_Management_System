﻿using InventoryManagement.DAL;
using InventoryManagement.DAL.Interface;
using InventoryManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace InventoryManagement.Controllers
{
    public class ProductController : Controller
    {
        // GET: Product
        //private readonly inventoryDbContext _inventoryDbContext;
        private readonly ICartItem _cartItem;
        private readonly IProduct _product;
        private readonly ICustomer _customer;
        private readonly ICart _cart;
        private readonly inventoryDbContext db; 

        public ProductController(ICartItem cartitem, IProduct product,ICustomer customer,ICart cart)
        {
            _cartItem = cartitem;
            _product = product;
            _customer = customer;
            _cart = cart;
        }
        public ProductController()
        {
            db = new inventoryDbContext();
            _product = new productRepo(db);
            _cartItem  = new CartItemRepo(db);
            _customer = new customerRepo(db);
        }
        public ActionResult ProductList(string name, decimal? minPrice, decimal? maxPrice, int? minQty, int? maxQty)
        {
            // Base query - IQueryable allows building SQL dynamically
            var filteredProducts = db.Products.Where(p =>
        (string.IsNullOrEmpty(name) || p.Name.Contains(name)) &&
        (!minPrice.HasValue || p.price >= minPrice.Value) &&
        (!maxPrice.HasValue || p.price <= maxPrice.Value) &&
        (!minQty.HasValue || p.quantityInStock >= minQty.Value) &&
        (!maxQty.HasValue || p.quantityInStock <= maxQty.Value)
    ).ToList();

            return View(filteredProducts);
        }
        public ActionResult Details(int productId)
        {

            var product = _product.GetProductById(productId);
            if (product == null)
            {
                return HttpNotFound();
            }
            return View(product);
        }
        [HttpPost]
        public ActionResult AddToCart(int customerId, int productId)
        {
            var customer = db.Customers.FirstOrDefault(c => c.SignupId == customerId);
            var product = db.Products.FirstOrDefault(p => p.Id == productId);

            if (customer == null || product == null) throw new Exception("Invalid user or product");

            var cart = db.Cart.FirstOrDefault(c => c.SignupId == customerId);

            if (cart == null)
            {
                cart = new Cart { SignupId = customerId };
                db.Cart.Add(cart);
                db.SaveChanges(); // To get CartId
            }

            var existingItem = db.CartItems.FirstOrDefault(ci => ci.CartId == cart.CartId && ci.ProductId == productId);

            if (existingItem != null && product.quantityInStock>0)
            {
                existingItem.Quantity += 1;
                existingItem.Price += product.price;
                product.quantityInStock -= 1;
                db.SaveChanges();
            }
            else if(product.quantityInStock>0)
            {
                db.CartItems.Add(new CartItem
                {
                    CartId = cart.CartId,
                    ProductId = productId,
                    Quantity = 1,
                    Price = product.price
                    
                });
                product.quantityInStock -= 1;
                db.SaveChanges();
            }
            else
            {
                TempData["Error"] = "Product is out of stock.";
                return RedirectToAction("ProductList", "Product");
            }
           return RedirectToAction("GetCustomerCartItem", "CartItem", new { customerId = customerId });
        }


    }
}