﻿using InventoryManagement.DAL.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using InventoryManagement.DTO;
using InventoryManagement.Models;
using InventoryManagement.Services;
using InventoryManagement.DAL;

namespace InventoryManagement.Controllers.customers
{
    public class SignupController : Controller
    {
        private readonly ISignup _signup;
        public SignupController()
        {
            _signup=new SignupRepo(new inventoryDbContext());
        }
        public SignupController(ISignup signup)
        {
            _signup = signup;
        }
        [HttpGet]
        [AllowAnonymous]
        public ActionResult Signup()
        {
            return View();
        }
        [HttpPost]
        [AllowAnonymous]
        public ActionResult Signup(customerSign c) 
        {
            if (ModelState.IsValid)
            {
                _signup.Signup(c);
                return RedirectToAction("Login","Login");
            }
            else
            {
                ModelState.AddModelError("Email", "Email already exist");
            }
                return View(c);
        }
    }
}