﻿using InventoryManagement.DAL.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Web;
using System.Web.Mvc;
using InventoryManagement.DTO;
using InventoryManagement.Models;
using System.Security.Cryptography;
using System.Web.Security;
using System.Data.Entity;

namespace InventoryManagement.Controllers.customers
{
    public class LoginController : Controller
    {
        private inventoryDbContext db=new inventoryDbContext();
        private readonly ILogin _loginRepo;
        public LoginController()
        {
            _loginRepo = new LoginRepo(new inventoryDbContext());
        }
        public LoginController(ILogin LoginRepo)
        {
            _loginRepo = LoginRepo;
        }
        
        // GET: Login
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(login model)
        {
           if(string.IsNullOrEmpty(model.Email) || string.IsNullOrEmpty(model.Password))
            {
                ModelState.AddModelError("", "Username and password are required");
                return View();
            }
           var user=db.CustomerSign.FirstOrDefault(u=>u.Email == model.Email && u.Password== model.Password);
            var name = db.CustomerSign.FirstOrDefault(u => u.Email==model.Email);
          
            if (user == null)
            {
                ModelState.AddModelError("", "Invalid username or password");
                return View();
                //return RedirectToAction("ForgotPassword","Account");
                //return Content("error in password/email");
            }
            
            FormsAuthentication.SetAuthCookie(user.Name, false);
            Session["CustomerId"]=user.SignupId;
            Session["CustomerName"] = user.Name;
            Session["CustomerEmail"]=user.Email;

            string returnUrl = Request.QueryString["ReturnUrl"];
            if (!string.IsNullOrEmpty(returnUrl))
            {
                return Redirect(returnUrl);
            }
            return RedirectToAction("dashboard", "Dashboard");
        }
    }
}