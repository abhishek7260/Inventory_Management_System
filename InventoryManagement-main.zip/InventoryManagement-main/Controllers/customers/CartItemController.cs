﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using InventoryManagement.DAL.Interface;
using InventoryManagement.DAL;
using InventoryManagement.Models;
using InventoryManagement.Services;
using InventoryManagement.DTO;

namespace InventoryManagement.Controllers.customers
{
    public class CartItemController : Controller
    {
        private readonly ICartItem _cart;
        private readonly ICustomer _customer;
        private readonly IProduct _product;
        private readonly inventoryDbContext db;
        public CartItemController(ICartItem cart,ICustomer customer,IProduct product)
        {
            _cart = cart;
            _customer = customer;
            _product = product;
        }
        public CartItemController()
        {
            db= new inventoryDbContext();
            _cart = new CartItemRepo(new inventoryDbContext());
            _customer = new customerRepo(new inventoryDbContext());
            _product = new productRepo(new inventoryDbContext());
        }

        //[HttpPost]
        //public ActionResult AddItem(int customerId,int  pId,int cartId)
        //{
        //    var customer=_customer.GetCustomerById(customerId);
        //    var product=_product.GetProductById(pId);
        //    if (customer == null || product == null)
        //    {
        //        return RedirectToAction("dashboard","Dashboard");
        //    }
        //    _cart.AddToCart(customerId,pId,cartId);
        //    return RedirectToAction("GetCustomerCartItem", new {customerId=customerId});

        //}
        [HttpGet]
        public ActionResult GetCustomerCartItem(int customerId)
        {
            var cart=db.Cart.FirstOrDefault(c=>c.SignupId==customerId);
            if (cart == null)
            {
                return HttpNotFound();
            }
            var cartItem = _cart.getAllProductOfCustomer(cart.CartId);
            return View(cartItem);
        }
        [HttpPost]
        //[ValidateAntiForgeryToken]
        public ActionResult DeleteCartItem(int cartid, int productId, int customerId)
        {
           

            _cart.RemoveItemFromCart(cartid, productId);
            return RedirectToAction("GetCustomerCartItem", "CartItem", new { customerId = customerId });
        }

        public ActionResult GetCartItems(int customerId)
        {
            return View();
        }
    }
}