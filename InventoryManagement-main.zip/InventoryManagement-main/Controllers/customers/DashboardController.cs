﻿using Microsoft.Ajax.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using InventoryManagement.Models;
using InventoryManagement.DTO;
using InventoryManagement.DAL;
using InventoryManagement.Services;
using InventoryManagement.DAL.Interface;


namespace InventoryManagement.Controllers.customers
{
    
    public class DashboardController : Controller
    {
        private readonly DashboardRepo dashboardRepo;
        public DashboardController() 
        {
            dashboardRepo = new DashboardRepo(new inventoryDbContext());
            
        }
       public ActionResult dashboard()
        {
            if (Session["customerId"] == null)
            {
                return RedirectToAction("Login","Login");
            }
            int customerId = (int)Session["CustomerId"];
            var customer=dashboardRepo.DashBoardItem(customerId);
            return View(customer);
        }
    } 
}