﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using InventoryManagement.Models;
using InventoryManagement.DTO;
using InventoryManagement.DAL;
using InventoryManagement.Services;
using InventoryManagement.DAL.Interface;

namespace InventoryManagement.Controllers.customers
{
    public class OrderInfoController : Controller
    {
        private readonly IOrder _order;
        private readonly inventoryDbContext _inventoryDbContext;

        public OrderInfoController()
        {
            _inventoryDbContext = new inventoryDbContext();
            _order = new orderRepo(_inventoryDbContext);
        }
        public OrderInfoController(IOrder order)
        {
            _order = order;
        }

        public ActionResult getOrderList()
        {
            int? customerId = Session["CustomerId"] as int?;
            if (customerId == null)
            {
                return RedirectToAction("dashboard", "Dashboard");
            }

            var orderProducts = _inventoryDbContext.OrderProducts
                .Include("Product")
                .Include("Order")
                .Where(op => op.Order.CustomerId == customerId.Value)
                .ToList();

            return View(orderProducts);  // ✅ Pass List<OrderProduct> to the view
        }
        [ActionName("cancelView")]
        public ActionResult CancelOrder(int customerId)
        {
            var c=_inventoryDbContext.Customers.FirstOrDefault(d=>d.SignupId==customerId);
            if (c == null)
            {
                return RedirectToAction("dashboard", "Dashboard");
            }
            var orders = _order.getOrderById(c.SignupId);
            return View(orders);
        }
        [ActionName("cancelDelete")]
        [HttpPost]
        public ActionResult DeleteOrders(int customerId)
        {
            var c=_inventoryDbContext.Customers.FirstOrDefault(d=>d.SignupId ==customerId);
            if(c==null)
            {
              return RedirectToAction("dashboard", "Dashboard"); 
            }
            _order.DeleteOrder(c.orderId);
            return RedirectToAction("dashboard", "Dashboard");
        }
        public ActionResult EditOrders(customer c)
        {
            if(c==null)
            {
                return RedirectToAction("dashboard", "Dashboard");
            }
            var orders=_order.getOrderById(c.SignupId);
            return View(orders);
        }
        //[HttpPost]
        //public ActionResult EditOrder(customer c)
        //{
        //    var order=_inventoryDbContext.Orders.FirstOrDefault(c.)
        //    if(c==null)
        //    {
        //        return RedirectToAction("dashboard", "Dashboard");
        //    }
        //    _order.UpdateOrder(c.orderId);
        //    return RedirectToAction("Index","Home");
        //}

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult PlaceOrders(int cartId)
        {
            var cart= _inventoryDbContext.Cart.FirstOrDefault(c=>c.CartId==cartId); 
            if (cart==null)
            {
                return HttpNotFound();
            }
            _order.PlaceOrder(cartId); 
            return RedirectToAction("getOrderList","OrderInfo");
        }
        //public ActionResult CartOrderDetails(int cartId)
        //{
        //    var result = _order.GetCartOrderDetails(cartId); // or _cartRepository
        //    return View(result); // View should expect CartOrderDetailsViewModel
        //}

    }
}