﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace InventoryManagement.Models
{
    public class inventoryDbContext:DbContext
    {
        public DbSet<order> Orders { get; set; }
        public DbSet<customer>Customers { get; set; }
        public DbSet<product>Products { get; set; }
        public DbSet<Category> Category { get; set; }
        public DbSet<customerSign> CustomerSign { get; set; }
        public DbSet<CustomerLogin> CustomerLogin { get; set; }
        public DbSet<Cart> Cart { get; set; }
        public DbSet<OrderProduct> OrderProducts { get; set; }
        public DbSet<CartItem> CartItems { get; set; }
        public DbSet<PasswordResetRequest> PasswordResetRequests { get; set; }

        
      
        public inventoryDbContext() : base("name=inventoryDbContext") { }

       
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            //configuring one-to-many relationship between OrderProduct and order
            modelBuilder.Entity<OrderProduct>()
                .HasRequired(o => o.Order)
                .WithMany(o => o.OrderProduct)
                .HasForeignKey(o => o.OrderId);

            //configuring one-to-many relationship between OrderProduct and Productc

            modelBuilder.Entity<OrderProduct>()
                .HasRequired(o => o.Product)
                .WithMany(o=>o.OrderProduct)
                .HasForeignKey(o => o.ProductId);
                

            //configuring one-to-many relationship between customer and order
            modelBuilder.Entity<order>()
                .HasRequired(o=>o.Customer)
                .WithMany(p=>p.Orders)
                .HasForeignKey(o => o.CustomerId);

            // configuring one-to- many or many-to-many relationship between category and product
            modelBuilder.Entity<product>()
                  .HasRequired(c => c.Category)
                  .WithMany(p => p.Products)
                  .HasForeignKey(p => p.CategoryId);


            modelBuilder.Entity<customer>()
                .HasKey(c=>c.SignupId);

            modelBuilder.Entity<CustomerLogin>()
                .HasKey(c => c.SignupId);

          
            // configuring one-to-one relationship between customer and customerSignUp
            modelBuilder.Entity<customer>()
                 .HasRequired(c => c.CustomerSign)
                 .WithOptional(s => s.Customers);

            modelBuilder.Entity<CustomerLogin>()
                .HasRequired(c => c.CustomerSign)
                .WithOptional(p => p.CustomerLogin);

            //modelBuilder.Entity<Cart>()
            //    .HasRequired(c => c.Product)
            //    .WithMany(c=>c.Cart)
            //    .HasForeignKey(c => c.ProductId);

            //modelBuilder.Entity<Cart>()
            //    .HasRequired(c => c.Customer)
            //    .WithOptional(c => c.Cart);

            modelBuilder.Entity<Cart>()
                .HasMany(c=>c.CartItem)
                .WithRequired(c=>c.Cart)
                .HasForeignKey(c=>c.CartId);

            modelBuilder.Entity<product>()
            .HasMany(p => p.CartItem)
            .WithRequired(ci => ci.Product)
            .HasForeignKey(ci => ci.ProductId);

            modelBuilder.Entity<Cart>()
            .HasKey(c => c.SignupId);

            modelBuilder.Entity<Cart>()
                .HasRequired(c => c.Customer)
                .WithOptional(cu => cu.Cart);

            modelBuilder.Entity<Cart>()
               .HasOptional(c => c.Order)       // Cart *may* have one Order
               .WithRequired(o => o.cart);      // Order *must* have one Cart


        }
    }
}