﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace InventoryManagement.Models
{
    public class product
    {
        [Key] //primary key for product table
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal price { get; set; }
        public int quantityInStock { get; set; }
        public int CategoryId { get; set; }
        public virtual ICollection<OrderProduct> OrderProduct { get; set; } //navigation property for product table and order table 
        public virtual Category Category { get; set; }
        //public virtual ICollection<Cart> Cart { get; set; }
        public virtual ICollection<CartItem> CartItem { get; set; }
    }
}