﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace InventoryManagement.Models
{
    public class customerSign
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int SignupId { get; set; }
        [Required]
        [StringLength(50,MinimumLength =3,ErrorMessage ="Name must be greater than 2 length character")]
        public string Name { get; set; }
        [Required(ErrorMessage ="email is required")]
        [EmailAddress]
        public string Email {  get; set; }
        [StringLength(50,MinimumLength =6,ErrorMessage ="Passwrod must be atleast 6 character")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Compare("Password",ErrorMessage ="Password do not match.")]
        [DataType(DataType.Password)]
        [NotMapped]
        public string ConfirmPassword { get; set; }
     
        public virtual CustomerLogin CustomerLogin { get; set; }
       
        public virtual customer Customers { get; set; }
    }
}