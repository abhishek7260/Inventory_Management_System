﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace InventoryManagement.Models
{
    public class customer
    {
        [Key,ForeignKey("CustomerSign")]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int SignupId { get; set; }
        [Required]
        [Display(Name="Customer Name")]
        public string Name { get; set; }
        [Required]
        public string Email {  get; set; }
        public int orderId { get; set; }
    
        
        public virtual ICollection<order> Orders { get; set; } //navigation property
        public virtual customerSign CustomerSign { get; set; }
        public virtual Cart Cart { get; set; }

    }
}