﻿using Antlr.Runtime.Tree;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace InventoryManagement.Models
{
    public class order
    {
        [Key, ForeignKey("cart")]
        public int CartId { get; set; }
        public DateTime orderDate { get; set; }
        
        public int CustomerId   { get; set; }
        
        //public int ProductId { get; set; }
        //public int quantity { get; set; }
        //public decimal TotalPrice { get; set; }
       
        public virtual Cart cart { get; set; }


        [ForeignKey("CustomerId")]
        public virtual customer Customer { get; set; } // navigation property between customer table and order table
        public ICollection<OrderProduct> OrderProduct { get; set; }
        //public ICollection<CartOrder> CartOrders { get; set; }
    }
}