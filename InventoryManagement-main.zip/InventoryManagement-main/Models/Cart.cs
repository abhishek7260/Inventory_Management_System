﻿using InventoryManagement.DAL.Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;


namespace InventoryManagement.Models
{
    public class Cart
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int CartId { get; set; }
        [ForeignKey("Customer")]
        public int SignupId { get; set; }
        public virtual customer Customer { get; set; }
        public virtual ICollection<CartItem> CartItem { get; set; }
        public virtual order Order { get; set; }

    }
}