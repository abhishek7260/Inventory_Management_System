﻿using InventoryManagement.Models;
using InventoryManagement.ViewModels;
using Microsoft.Ajax.Utilities;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace InventoryManagement.DAL.Interface
{
    public class orderRepo : IOrder
    {
        private inventoryDbContext _db;
        public orderRepo(inventoryDbContext db)
        {
            _db = db;
        }
        public IEnumerable<order> GetOrders()
        {
            return _db.Orders.Include(c => c.Customer).ToList();
        }
        public List<order> getOrderById(int CustomerId)
        {
            return _db.Orders.Include("OrderProduct.Product")
                .Include(p => p.Customer)
                .Where(o => o.CustomerId == CustomerId).ToList();
        }
        public void UpdateOrder(order order)
        {
            _db.Entry(order).State = EntityState.Modified;
            _db.SaveChanges();
        }
        public void DeleteOrder(int id)
        {
            var emp = _db.Orders.Find(id);
            if (emp != null)
            {
                _db.Orders.Remove(emp);
                _db.SaveChanges();
            }
        }
        public void PlaceOrder(int cartId)
        {
            try
            {
                // 1. Check if order already placed for this cart
                if (_db.Orders.Any(o => o.CartId == cartId))
                {
                    Debug.WriteLine("Order already exists for CartId: " + cartId);
                    return;
                }

                // 2. Get cart with items and products
                var cart = _db.Cart
                              .Include("CartItem.Product")
                              .FirstOrDefault(c => c.CartId == cartId);

                if (cart == null)
                {
                    Debug.WriteLine("Cart not found for CartId: " + cartId);
                    return;
                }

                if (cart.CartItem == null || !cart.CartItem.Any())
                {
                    Debug.WriteLine("Cart has no items.");
                    return;
                }

                // 3. Create the Order (CartId is PK and FK)
                var order = new order
                {
                    CartId = cart.CartId,
                    CustomerId = cart.SignupId,
                    orderDate = DateTime.Now,
                    OrderProduct = new List<OrderProduct>()
                };

                _db.Orders.Add(order);
                _db.SaveChanges(); // Save Order to DB
                Debug.WriteLine("Order created with CartId (OrderId): " + order.CartId);

                // 4. Move CartItems to OrderProducts
                foreach (var item in cart.CartItem)
                {
                    var orderProduct = new OrderProduct
                    {
                        OrderId = order.CartId,
                        ProductId = item.ProductId,
                        Quantity = item.Quantity,
                        Price = item.Price
                    };

                    _db.OrderProducts.Add(orderProduct);
                    Debug.WriteLine($"Added OrderProduct → ProductId: {item.ProductId}, Qty: {item.Quantity}, Price: {item.Price}");
                }

                // 5. Remove CartItems
                _db.CartItems.RemoveRange(cart.CartItem);
                Debug.WriteLine("CartItems removed: " + cart.CartItem.Count);

                // 6. Final Save
                _db.SaveChanges();
                Debug.WriteLine("OrderProducts saved successfully.");
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Exception while placing order: " + ex.Message);
                throw; // Optional: rethrow or handle
            }
        }


        public CartOrderDetailsViewModel GetCartOrderDetails(int cartId)
        {
            var cartItems = _db.CartItems
                .Include(ci => ci.Product)
                .Where(ci => ci.CartId == cartId)
                .ToList();

            var order = _db.Orders.FirstOrDefault(o => o.CartId == cartId);

            var orderProducts = new List<OrderProduct>();

            if (order != null)
            {
                orderProducts = _db.OrderProducts
                    .Include(op => op.Product)
                    .Where(op => op.OrderId == order.CartId)
                    .ToList();
            }

            return new CartOrderDetailsViewModel
            {
                CartItems = cartItems,
                OrderProducts = orderProducts
            };
        }

        //public void PlaceOrderFromCart(int customerId)
        //{
        //    // Step 1: Get the cart for this customer
        //    var cart = _db.Cart
        //        .Include(c => c.CartItem.Select(ci => ci.Product))
        //        .FirstOrDefault(c => c.SignupId == customerId);

        //    if (cart == null || !cart.CartItem.Any())
        //        throw new InvalidOperationException("Cart is empty or does not exist.");

        //    // Step 2: Create the new order
        //    var order = new order
        //    {
        //        CustomerId = customerId,
        //        orderDate = DateTime.Now,
        //        OrderProduct = new List<OrderProduct>()
        //    };

        //    // Step 3: Process each CartItem
        //    foreach (var item in cart.CartItem)
        //    {
        //        var product = item.Product;

        //        if (product.quantityInStock >= item.Quantity)
        //        {
        //            order.OrderProduct.Add(new OrderProduct
        //            {
        //                ProductId = product.Id,
        //                Quantity = item.Quantity,
        //                Price = product.price * item.Quantity
        //            });

        //            // Reduce stock
        //            product.quantityInStock -= item.Quantity;
        //        }
        //        else
        //        {
        //            throw new InvalidOperationException($"Not enough stock for product: {product.Name}");
        //        }
        //    }

        //    // Step 4: Save the order and clear the cart
        //    _db.Orders.Add(order);
        //    _db.CartItems.RemoveRange(cart.CartItem);
        //    _db.SaveChanges();
        //}
    }

    }