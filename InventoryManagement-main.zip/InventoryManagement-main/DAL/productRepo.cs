﻿using InventoryManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;


namespace InventoryManagement.DAL.Interface
{
    public class productRepo : IProduct
    {
        private inventoryDbContext _db;
        public productRepo(inventoryDbContext db)
        {
            _db = db;
        }
        public IEnumerable<product> GetAllProduct()
        {
            return _db.Products.Include(c=>c.Category).ToList();
        }
        public product GetProductById(int productId)
        {
            return _db.Products.Find(productId);
        }
        public void AddProduct(product p)
        {
            _db.Products.Add(p);
            _db.SaveChanges();
        }
        public void UpdateProduct(product p)
        {
            _db.Entry(p).State = EntityState.Modified;
        }
        public void DeleteProduct(int productId)
        {
            var product = _db.Products.Find(productId);
            if (product != null)
            {
                _db.Products.Remove(product);
                _db.SaveChanges();
            }
        }
    }
}