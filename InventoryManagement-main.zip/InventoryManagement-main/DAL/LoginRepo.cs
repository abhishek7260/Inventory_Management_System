﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Models;
using InventoryManagement.DAL;
using InventoryManagement.DTO;

namespace InventoryManagement.DAL.Interface
{
    public class LoginRepo:ILogin
    {
        private inventoryDbContext _inventoryDbContext;
        public LoginRepo(inventoryDbContext inventoryDbContext)
        {
            _inventoryDbContext = inventoryDbContext;
        }
        public customer Login(login dto)
        {
            var loginUser=_inventoryDbContext.CustomerSign.FirstOrDefault(x => x.Email == dto.Email && x.Password==dto.Password);
            if(loginUser == null)
            {
                return null;
            }

            return loginUser.Customers; // returning associated customer with signup
            
        }

    }
}