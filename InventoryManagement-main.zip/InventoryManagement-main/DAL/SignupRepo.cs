﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using InventoryManagement.DAL;
using InventoryManagement.DAL.Interface;
using InventoryManagement.DTO;
using InventoryManagement.Models;

namespace InventoryManagement.DAL
{
    public class SignupRepo:ISignup
    {
        private readonly inventoryDbContext _inventoryDbContext;
        public SignupRepo(inventoryDbContext inventoryDbContext)
        {
            _inventoryDbContext = inventoryDbContext;
        }
        public void Signup(customerSign c)
        {
            var user = _inventoryDbContext.CustomerSign.FirstOrDefault(x=>x.Email==c.Email);
            if(user==null) 
                {
                    if (c.Email!=null && c.Password == c.ConfirmPassword)
                    {
                        _inventoryDbContext.CustomerSign.Add(c);
                    _inventoryDbContext.SaveChanges();
                    var login = new Models.customer
                    {
                        SignupId = c.SignupId,
                        Name =c.Name,
                        Email = c.Email,
                        

                    };
                    _inventoryDbContext.Customers.Add(login);
                        _inventoryDbContext.SaveChanges();
                    
                    }
                }
            }
    }
}