﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Models;
using InventoryManagement.DAL.Interface;

namespace InventoryManagement.DAL
{
    public class Cartrepo:ICart
    {
        private readonly inventoryDbContext _inventoryDbContext;
        public  Cartrepo(inventoryDbContext inventoryDbContext)
        {
            _inventoryDbContext = inventoryDbContext;
        }
        public void GetCartById(int id, int customerId)
        {
            var cart = _inventoryDbContext.Cart.FirstOrDefault(c => c.CartId == id);
            if (cart == null)
            {
                cart = new Cart { SignupId = customerId };
                _inventoryDbContext.Cart.Add(cart);
                _inventoryDbContext.SaveChanges();
            }

        }
    }
}