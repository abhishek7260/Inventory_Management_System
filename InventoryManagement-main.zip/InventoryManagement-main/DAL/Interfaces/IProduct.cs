﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Models;

namespace InventoryManagement.DAL
{
    public interface IProduct
    {
        IEnumerable<product> GetAllProduct();
        product GetProductById(int productId);
        void AddProduct(product p);
        void UpdateProduct(product p);
        void DeleteProduct(int p);
    }
}