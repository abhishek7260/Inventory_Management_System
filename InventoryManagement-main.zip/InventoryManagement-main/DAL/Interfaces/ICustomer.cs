﻿using InventoryManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InventoryManagement.DAL
{
    public interface ICustomer
    {
        IEnumerable<customer> GetAllCustomers();
        customer GetCustomerById(int id);
        void AddCustomer(customer c);
        void UpdateCustomer(customer c);
        void DeleteCustomer(int id);
    }
}