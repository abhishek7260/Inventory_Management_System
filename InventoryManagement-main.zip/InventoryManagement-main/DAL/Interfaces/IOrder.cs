﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Models;

namespace InventoryManagement.DAL
{
    public interface IOrder
    {
       IEnumerable<order>GetOrders();
        order getOrderById(int orderId);
        void AddOrder(order r);
        void UpdateOrder(order r);
        void DeleteOrder(int id);
    }
}