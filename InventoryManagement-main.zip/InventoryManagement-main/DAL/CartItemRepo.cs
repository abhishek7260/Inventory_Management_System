﻿using InventoryManagement.DAL.Interface;
using InventoryManagement.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
namespace InventoryManagement.DAL
{
    public class CartItemRepo : ICartItem
    {
        private readonly inventoryDbContext _inventoryDbContext;
        public CartItemRepo(inventoryDbContext inventoryDbContext)
        {
            _inventoryDbContext = inventoryDbContext;
        }
        public IEnumerable<CartItem> getAllProductOfCustomer(int cartId)
        {
            var car = _inventoryDbContext.CartItems
                .Include("Product")
                .Where(c => c.CartId == cartId).ToList();
            //.Select(c=>c.Product);
            return car;
        }
        public void AddToCart(int cartid,int productId,int customerId)
        {

            var ExistingItem=_inventoryDbContext.CartItems.FirstOrDefault(c=>c.ProductId==productId && c.CartId==cartid);
            var product=_inventoryDbContext.Products.FirstOrDefault(c=>c.Id==productId);
            if (ExistingItem != null)
            {
                ExistingItem.Quantity += 1;
                product.quantityInStock -= 1;
            }
            else
            {
                var car = new CartItem
                {
                    CartId= cartid,
                    ProductId = productId,
                    Quantity=1,
                };
                _inventoryDbContext.CartItems.Add(car);
                product.quantityInStock -= 1;
            }
            
           _inventoryDbContext.SaveChanges();
        }

        public void UpdateCartItem(int cartId, int newQuantity)
        {
            var cartItem = _inventoryDbContext.CartItems.Find(cartId);
            if (cartItem != null)
            {
                cartItem.Quantity = newQuantity;
                _inventoryDbContext.SaveChanges();
            }
        }
        //public void EditCartItems(Cart cart)
        //{
        //    _inventoryDbContext.Entry(cart).State= EntityState.Modified;
       
        //}
        public void RemoveItemFromCart(int cartId, int productId)
        {
            var items=_inventoryDbContext.CartItems.FirstOrDefault(c=>c.CartId==cartId && c.ProductId==productId);
            var product = _inventoryDbContext.Products.FirstOrDefault(c => c.Id == productId);
            if(items != null)
            {
                _inventoryDbContext.CartItems.Remove(items);
                product.quantityInStock += items.Quantity;
            }
            _inventoryDbContext.SaveChanges();
        }

    }
}