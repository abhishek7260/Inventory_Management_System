﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.DTO;
using InventoryManagement.Models;

namespace InventoryManagement.DAL.Interface
{
    public interface ILogin
    {
        customer Login(login dto);
    }
}