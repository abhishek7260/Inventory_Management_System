﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Models;
namespace InventoryManagement.DAL.Interface
{
    public interface ICustomer
    {
        IEnumerable<customer> GetAllCustomers();
        customer GetCustomerById(int id);
        void AddCustomer(customer customer);
        void UpdateCustomer(customer customer);
        void DeleteCustomer(int id);

    }
}