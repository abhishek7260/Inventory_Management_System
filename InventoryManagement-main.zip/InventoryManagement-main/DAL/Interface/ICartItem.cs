﻿using System;
using System.Collections.Generic;
using System.Linq;
using InventoryManagement.Models;
using System.Web;

namespace InventoryManagement.DAL.Interface
{
    public interface ICartItem
    {
        //void AddToCart(int cartid, int productId);
        IEnumerable<CartItem> getAllProductOfCustomer(int customerId);

        //void EditCartItems(Cart cart);
        void UpdateCartItem(int cartId, int newQuantity);
        void RemoveItemFromCart(int customerId, int productId);

    }
}