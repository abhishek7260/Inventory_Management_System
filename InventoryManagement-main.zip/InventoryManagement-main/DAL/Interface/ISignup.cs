﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Models;

namespace InventoryManagement.DAL.Interface
{
    public interface ISignup
    {
        void Signup(customerSign c);
    }
}