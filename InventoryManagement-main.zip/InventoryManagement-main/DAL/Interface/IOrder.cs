﻿using InventoryManagement.Models;
using InventoryManagement.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InventoryManagement.DAL.Interface
{
    public interface IOrder
    {
        IEnumerable<order> GetOrders();
        List<order> getOrderById(int id);
        
        void UpdateOrder(order order);
        void DeleteOrder(int id);
        void PlaceOrder(int cartId);
        CartOrderDetailsViewModel GetCartOrderDetails(int cartId);
        //void PlaceOrderFromCart(int customerId);
    }
}