﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using InventoryManagement.Models;
using System.Data.Entity;

namespace InventoryManagement.DAL.Interface
{
    public class customerRepo:ICustomer
    {
        private inventoryDbContext _dbContext;
        public customerRepo(inventoryDbContext dbContext)
        {
            _dbContext = dbContext;
        }
        public IEnumerable<customer> GetAllCustomers()
        {
            return _dbContext.Customers.ToList();
        }
        public customer GetCustomerById(int id)
        {
            return _dbContext.Customers.Find(id);
        }

        public void AddCustomer(customer customer)
        {
            _dbContext.Customers.Add(customer);
            _dbContext.SaveChanges();
        }
        public void DeleteCustomer(int id)
        {
            _dbContext.Customers.Remove(GetCustomerById(id));
            _dbContext.SaveChanges();
        }
        public void UpdateCustomer(customer customer)
        {
            _dbContext.Entry(customer).State=EntityState.Modified;
            _dbContext.SaveChanges();
        }
    }
}