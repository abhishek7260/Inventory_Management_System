﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Models;
using InventoryManagement.DTO;
using InventoryManagement.ViewModels;

namespace InventoryManagement.DAL.Interface
{
    public class DashboardRepo:IDashboard
    {
        private readonly inventoryDbContext _inventoryDbContext;
        public DashboardRepo(inventoryDbContext inventoryDbContext)
        {
            _inventoryDbContext = inventoryDbContext;
        }
        public CustomerDashboardViewModel DashBoardItem(int customerId)
        {
            var customer=_inventoryDbContext.Customers.FirstOrDefault(c=>c.SignupId == customerId);
            var cart = _inventoryDbContext.Cart
               .Include("CartItem.Product")
                .FirstOrDefault(ci => ci.SignupId == customerId); // or use cart ID
                  

            var cartItems = cart?.CartItem?.ToList() ?? new List<CartItem>();

            var orders =_inventoryDbContext.Orders.Where(o=>o.CustomerId==customerId).ToList();
            var orderIds=orders.Select(o=>o.CartId).ToList();   
            var orderProducts=_inventoryDbContext.OrderProducts.Include("Product").Include("Order").Where(op=>orderIds.Contains(op.OrderId)).ToList();
            var viewModel = new CustomerDashboardViewModel
            {
                Customer = customer,
                CartItems = cartItems,
                Orders = orders,
                OrderProducts = orderProducts,
            };
            return viewModel;

        }
    }
}