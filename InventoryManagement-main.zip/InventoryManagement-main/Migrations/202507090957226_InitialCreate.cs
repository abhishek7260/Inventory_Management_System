﻿namespace InventoryManagement.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Carts",
                c => new
                    {
                        SignupId = c.Int(nullable: false),
                        CartId = c.Int(nullable: false, identity: true),
                    })
                .PrimaryKey(t => t.SignupId)
                .ForeignKey("dbo.customers", t => t.SignupId)
                .Index(t => t.SignupId);
            
            CreateTable(
                "dbo.CartItems",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        CartId = c.Int(nullable: false),
                        ProductId = c.Int(nullable: false),
                        Quantity = c.Int(nullable: false),
                        Price = c.Decimal(nullable: false, precision: 18, scale: 2),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.products", t => t.ProductId, cascadeDelete: true)
                .ForeignKey("dbo.Carts", t => t.CartId, cascadeDelete: true)
                .Index(t => t.CartId)
                .Index(t => t.ProductId);
            
            CreateTable(
                "dbo.products",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false),
                        Description = c.String(),
                        price = c.Decimal(nullable: false, precision: 18, scale: 2),
                        quantityInStock = c.Int(nullable: false),
                        CategoryId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Categories", t => t.CategoryId, cascadeDelete: true)
                .Index(t => t.CategoryId);
            
            CreateTable(
                "dbo.Categories",
                c => new
                    {
                        CategoryId = c.Int(nullable: false, identity: true),
                        CategoryName = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.CategoryId);
            
            CreateTable(
                "dbo.OrderProducts",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        OrderId = c.Int(nullable: false),
                        ProductId = c.Int(nullable: false),
                        Quantity = c.Int(nullable: false),
                        Price = c.Decimal(nullable: false, precision: 18, scale: 2),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.orders", t => t.OrderId, cascadeDelete: true)
                .ForeignKey("dbo.products", t => t.ProductId, cascadeDelete: true)
                .Index(t => t.OrderId)
                .Index(t => t.ProductId);
            
            CreateTable(
                "dbo.orders",
                c => new
                    {
                        CartId = c.Int(nullable: false),
                        orderDate = c.DateTime(nullable: false),
                        CustomerId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.CartId)
                .ForeignKey("dbo.customers", t => t.CustomerId, cascadeDelete: true)
                .ForeignKey("dbo.Carts", t => t.CartId)
                .Index(t => t.CartId)
                .Index(t => t.CustomerId);
            
            CreateTable(
                "dbo.customers",
                c => new
                    {
                        SignupId = c.Int(nullable: false),
                        Name = c.String(nullable: false),
                        Email = c.String(nullable: false),
                        orderId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.SignupId)
                .ForeignKey("dbo.customerSigns", t => t.SignupId)
                .Index(t => t.SignupId);
            
            CreateTable(
                "dbo.customerSigns",
                c => new
                    {
                        SignupId = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false, maxLength: 50),
                        Email = c.String(nullable: false),
                        Password = c.String(maxLength: 50),
                    })
                .PrimaryKey(t => t.SignupId);
            
            CreateTable(
                "dbo.CustomerLogins",
                c => new
                    {
                        SignupId = c.Int(nullable: false),
                        Email = c.String(nullable: false),
                        Password = c.String(),
                    })
                .PrimaryKey(t => t.SignupId)
                .ForeignKey("dbo.customerSigns", t => t.SignupId)
                .Index(t => t.SignupId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.orders", "CartId", "dbo.Carts");
            DropForeignKey("dbo.Carts", "SignupId", "dbo.customers");
            DropForeignKey("dbo.CartItems", "CartId", "dbo.Carts");
            DropForeignKey("dbo.OrderProducts", "ProductId", "dbo.products");
            DropForeignKey("dbo.OrderProducts", "OrderId", "dbo.orders");
            DropForeignKey("dbo.orders", "CustomerId", "dbo.customers");
            DropForeignKey("dbo.customers", "SignupId", "dbo.customerSigns");
            DropForeignKey("dbo.CustomerLogins", "SignupId", "dbo.customerSigns");
            DropForeignKey("dbo.products", "CategoryId", "dbo.Categories");
            DropForeignKey("dbo.CartItems", "ProductId", "dbo.products");
            DropIndex("dbo.CustomerLogins", new[] { "SignupId" });
            DropIndex("dbo.customers", new[] { "SignupId" });
            DropIndex("dbo.orders", new[] { "CustomerId" });
            DropIndex("dbo.orders", new[] { "CartId" });
            DropIndex("dbo.OrderProducts", new[] { "ProductId" });
            DropIndex("dbo.OrderProducts", new[] { "OrderId" });
            DropIndex("dbo.products", new[] { "CategoryId" });
            DropIndex("dbo.CartItems", new[] { "ProductId" });
            DropIndex("dbo.CartItems", new[] { "CartId" });
            DropIndex("dbo.Carts", new[] { "SignupId" });
            DropTable("dbo.CustomerLogins");
            DropTable("dbo.customerSigns");
            DropTable("dbo.customers");
            DropTable("dbo.orders");
            DropTable("dbo.OrderProducts");
            DropTable("dbo.Categories");
            DropTable("dbo.products");
            DropTable("dbo.CartItems");
            DropTable("dbo.Carts");
        }
    }
}
